import 'dart:io';

import '/Getxcontroller/controllerphoneinfo.dart';
import '/Pages/Contacts.dart';
import '/Pages/Half%20On%20.dart';
import '/Pages/PasswordApp.dart';
import '/Pages/Relleh/Relleh%20windows.dart';
import '/Pages/Relleh/Relleh.dart';
import '/Pages/Setting.dart';
import '/Pages/Simcard.dart';
import '/Pages/add%20device.dart';
import '/Pages/password%20device.dart';
import '/color.dart';
import '/testpage/fn_onoff.dart';
import '/testpage/select%20page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:badges/badges.dart' as badges;
import 'package:progressive_image/progressive_image.dart';

import '../Getxcontroller/controllerOnOff.dart';

class HomePage2 extends StatefulWidget {
  const HomePage2({super.key});

  @override
  State<HomePage2> createState() => _HomePage2State();
}

class _HomePage2State extends State<HomePage2> {
  @override
  void initState() {
    //ifgotoadddevice();
    // TODO: implement initState
    super.initState();
  }

  ifgotoadddevice() async {
    await Future.delayed(Duration(seconds: 1));
    if (Get.find<controllerphoneinfo>(tag: 'secend').lenghtmainpage.value ==
        0) {
      Get.off(AddDevice());
    } else if (Get.find<controllerphoneinfo>(tag: 'secend')
                .lenghtmainpage
                .value >=
            2 &&
        Get.find<controllerphoneinfo>(tag: 'secend').selectpage.value ==
            false) {
      Get.off(SelectPage());
    }
  }

  @override
  Widget build(BuildContext context) {
    final GlobalKey<ScaffoldState> _scaffoldKey =
        new GlobalKey<ScaffoldState>();
    return Scaffold(
      //  backgroundColor: Colors.black,
      /*  appBar: AppBar(
        title: Text('ermiya'),
      ), */
      key: _scaffoldKey,
      endDrawer: Drawer(
        width: Get.width * 0.65,
        backgroundColor: Colors.black,
        child: drawer(),
      ),
      body: Center(
          child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: Get.width * 0.4,
            height: Get.height,
            // margin: EdgeInsets.symmetric(vertical: 5, horizontal: 3),
            /*  decoration: BoxDecoration(
              //   shape: BoxShape.rectangle,
              borderRadius: BorderRadius.circular(50),
              color: Color.fromARGB(255, 34, 33, 33),
              boxShadow: [
                BoxShadow(
                  color: theme[
                                Get.find<controllerphoneinfo>(tag: 'secend')
                                    .theme
                                    .value]![5],
                  spreadRadius: 5,
                  blurRadius: 10,
                ),
              ],
            ), */
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(
                    height: 15,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 30),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: InkWell(
                        onTap: () {
                          for (var i = 0; i < 10; i++) {
                            Get.find<controllerphoneinfo>(tag: 'secend')
                                .select_dev[i]
                                .value = true;
                          }
                        },
                        child: Text(
                          'انتخاب همه',
                          style: TextStyle(fontFamily: 'A'),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Column(
                    children: List.generate(
                        10,
                        (index) => box_device(
                              index: index,
                            )),
                  ),
                ],
              ),
            ),
          ),
          Obx(() {
            return Visibility(
              visible: Get.find<controlleronoff>(tag: 'secend').relleh.value,
              child: Relleh_windows(),
              replacement: Container(
                width: Get.width * 0.6,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 50, vertical: 5),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                                height: Get.height * 0.2,
                                child: ProgressiveImage(
                                  placeholder: const AssetImage(
                                    'assets/logo.png',
                                  ),
                                  thumbnail: const AssetImage(
                                    'assets/logo.png',
                                  ),
                                  image: const AssetImage(
                                    'assets/logo.png',
                                  ),
                                  height: Get.height * 0.2,
                                  width: Get.height * 0.2,
                                )),
                            InkWell(
                                onTap: () =>
                                    _scaffoldKey.currentState!.openEndDrawer(),
                                child: SvgPicture.asset('assets/setting.svg'))
                          ],
                        ),
                      ),
                      Container(
                        width: Get.width * 0.6,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            InkWell(
                              onTap: () => offdev(),
                              child: Obx(() {
                                return Container(
                                  width: Get.find<controllerphoneinfo>(
                                                  tag: 'secend')
                                              .OnPhones
                                              .value ==
                                          'off'
                                      ? Get.width * 0.10
                                      : Get.width * 0.07,
                                  height: Get.find<controllerphoneinfo>(
                                                  tag: 'secend')
                                              .OnPhones
                                              .value ==
                                          'off'
                                      ? Get.width * 0.10
                                      : Get.width * 0.07,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.black,
                                    boxShadow: [
                                      BoxShadow(
                                        color: theme[
                                            Get.find<controllerphoneinfo>(
                                                    tag: 'secend')
                                                .theme
                                                .value]![5],
                                        spreadRadius: 5,
                                        blurRadius: 10,
                                      ),
                                    ],
                                  ),
                                  child: FittedBox(
                                      child: Center(
                                          child: SvgPicture.asset(
                                    'assets/lock-open.svg',
                                    color: Get.find<controllerphoneinfo>(
                                                    tag: 'secend')
                                                .OnPhones
                                                .value ==
                                            'off'
                                        ? theme[Get.find<controllerphoneinfo>(
                                                tag: 'secend')
                                            .theme
                                            .value]![3]
                                        : null,
                                  ))),
                                );
                              }),
                            ),

                            ///
                            ///
                            InkWell(
                              onTap: () => ondev(),
                              child: Obx(() {
                                return Container(
                                  width: Get.find<controllerphoneinfo>(
                                                  tag: 'secend')
                                              .OnPhones
                                              .value ==
                                          'on'
                                      ? Get.width * 0.10
                                      : Get.width * 0.07,
                                  height: Get.find<controllerphoneinfo>(
                                                  tag: 'secend')
                                              .OnPhones
                                              .value ==
                                          'on'
                                      ? Get.width * 0.10
                                      : Get.width * 0.07,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.black,
                                    boxShadow: [
                                      BoxShadow(
                                        color: theme[
                                            Get.find<controllerphoneinfo>(
                                                    tag: 'secend')
                                                .theme
                                                .value]![5],
                                        spreadRadius: 5,
                                        blurRadius: 10,
                                      ),
                                    ],
                                  ),
                                  child: FittedBox(
                                    child: Center(
                                      child: SvgPicture.asset(
                                        'assets/lock.svg',
                                        color: Get.find<controllerphoneinfo>(
                                                        tag: 'secend')
                                                    .OnPhones
                                                    .value ==
                                                'on'
                                            ? theme[
                                                Get.find<controllerphoneinfo>(
                                                        tag: 'secend')
                                                    .theme
                                                    .value]![3]
                                            : null,
                                      ),
                                    ),
                                  ),
                                );
                              }),
                            ),

                            ///
                            ///
                            InkWell(
                              onTap: () => Get.to(HalfOn()),
                              child: Obx(() {
                                return Container(
                                  width: Get.find<controllerphoneinfo>(
                                                  tag: 'secend')
                                              .OnPhones
                                              .value ==
                                          'halfon'
                                      ? Get.width * 0.10
                                      : Get.width * 0.07,
                                  height: Get.find<controllerphoneinfo>(
                                                  tag: 'secend')
                                              .OnPhones
                                              .value ==
                                          'on'
                                      ? Get.width * 0.10
                                      : Get.width * 0.07,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.black,
                                    boxShadow: [
                                      BoxShadow(
                                        color: theme[
                                            Get.find<controllerphoneinfo>(
                                                    tag: 'secend')
                                                .theme
                                                .value]![5],
                                        spreadRadius: 5,
                                        blurRadius: 10,
                                      ),
                                    ],
                                  ),
                                  child: FittedBox(
                                      child: Center(
                                          child: SvgPicture.asset(
                                    'assets/check.svg',
                                    color: Get.find<controllerphoneinfo>(
                                                    tag: 'secend')
                                                .OnPhones
                                                .value ==
                                            'halfon'
                                        ? theme[Get.find<controllerphoneinfo>(
                                                tag: 'secend')
                                            .theme
                                            .value]![3]
                                        : null,
                                  ))),
                                );
                              }),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        children: [
                          Obx(() {
                            return Text(
                              Get.find<controllerphoneinfo>(tag: 'secend')
                                          .OnPhones
                                          .value ==
                                      'on'
                                  ? 'فعال'
                                  : Get.find<controllerphoneinfo>(tag: 'secend')
                                              .OnPhones
                                              .value ==
                                          'off'
                                      ? 'غیر فعال'
                                      : 'نیمه فعال',
                              style: TextStyle(
                                  fontFamily: 'A',
                                  fontSize: 30,
                                  color: Colors.white),
                            );
                          }),
                          Obx(() {
                            return SvgPicture.asset(
                              'assets/${Get.find<controllerphoneinfo>(tag: 'secend').OnPhones.value == 'on' ? 'lock' : Get.find<controllerphoneinfo>(tag: 'secend').OnPhones.value == 'off' ? 'lock-open' : 'check'}.svg',
                              height: Get.height * 0.3,
                              color: theme[
                                  Get.find<controllerphoneinfo>(tag: 'secend')
                                      .theme
                                      .value]![3],
                            );
                          }),
                          Transform(
                            transform: Matrix4.identity()
                              ..translate(0.0, 0.0)
                              ..rotateZ(-0.02),
                            child: Container(
                              /*  width: 100.36,
                          height: 36.61, */
                              width: 283.36,
                              height: 36.61,
                              decoration: ShapeDecoration(
                                shape: OvalBorder(
                                  side: BorderSide(
                                      width: 3, color: Color(0x0C2C2C2C)),
                                ),
                                shadows: [
                                  BoxShadow(
                                    color: theme[Get.find<controllerphoneinfo>(
                                            tag: 'secend')
                                        .theme
                                        .value]![3],
                                    blurRadius: 20,
                                    offset: Offset(0, 0),
                                    spreadRadius: 0,
                                  )
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    ]),
              ),
            );
          }),
        ],
      )),
    );
  }
}

class box_device extends StatelessWidget {
  const box_device({super.key, required this.index});
  final int index;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: Get.width * 0.35,
      height: Get.height * 0.09,
      margin: EdgeInsets.symmetric(vertical: 5),
      decoration: ShapeDecoration(
        color:
            theme[Get.find<controllerphoneinfo>(tag: 'secend').theme.value]![4],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        shadows: [
          BoxShadow(
            color: theme[
                Get.find<controllerphoneinfo>(tag: 'secend').theme.value]![5],
            blurRadius: 8,
            offset: Offset(0, 0),
            spreadRadius: 0,
          )
        ],
      ),
      child: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Obx(() {
              return Checkbox(
                  value: Get.find<controllerphoneinfo>(tag: 'secend')
                      .select_dev[index]
                      .value,
                  onChanged: (value) {
                    Get.find<controllerphoneinfo>(tag: 'secend')
                        .select_dev[index]
                        .value = value!;
                  });
            }),
            SizedBox(
              width: Get.width * 0.177,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text('چراغ 1'),
                      Container(
                        width: 20,
                        height: 20,
                        decoration: ShapeDecoration(
                          color: index % 3 == 0
                              ? Color.fromARGB(255, 0, 137, 21)
                              : Color.fromARGB(255, 137, 21, 0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          shadows: [
                            BoxShadow(
                              color: index % 3 == 0
                                  ? Color.fromARGB(126, 68, 227, 115)
                                  : Color.fromARGB(125, 227, 68, 68),
                              blurRadius: 8,
                              offset: Offset(0, 0),
                              spreadRadius: 0,
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text('چراغ 2'),
                      Container(
                        width: 20,
                        height: 20,
                        decoration: ShapeDecoration(
                          color: index % 2.5 > 1
                              ? Color.fromARGB(255, 0, 137, 21)
                              : Color.fromARGB(255, 137, 21, 0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          shadows: [
                            BoxShadow(
                              color: index % 2.5 > 1
                                  ? Color.fromARGB(126, 68, 227, 115)
                                  : Color.fromARGB(125, 227, 68, 68),
                              blurRadius: 8,
                              offset: Offset(0, 0),
                              spreadRadius: 0,
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text('چراغ 3'),
                      Container(
                        width: 20,
                        height: 20,
                        decoration: ShapeDecoration(
                          color: index % 3.3 > 1.5
                              ? Color.fromARGB(255, 0, 137, 21)
                              : Color.fromARGB(255, 137, 21, 0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          shadows: [
                            BoxShadow(
                              color: index % 3.3 > 1.5
                                  ? Color.fromARGB(126, 68, 227, 115)
                                  : Color.fromARGB(125, 227, 68, 68),
                              blurRadius: 8,
                              offset: Offset(0, 0),
                              spreadRadius: 0,
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    '${name_dev[index]}',
                    style: TextStyle(fontFamily: 'A'),
                  ),
                  Text(
                    '0992299365$index',
                    style: TextStyle(fontFamily: 'A'),
                  ),
                  Row(
                    children: [
                      Text(
                        index % 2 == 0
                            ? 'فعال     '
                            : index % 1.5 == 0
                                ? 'غیر فعال '
                                : 'نیمه فعال',
                        style: TextStyle(fontFamily: 'A'),
                        textAlign: TextAlign.right,
                        textDirection: TextDirection.rtl,
                      ),
                      Container(
                        width: 20,
                        height: 20,
                        decoration: ShapeDecoration(
                          color: index % 2 == 0
                              ? Color.fromARGB(255, 0, 137, 21)
                              : index % 1.5 == 0
                                  ? Color.fromARGB(255, 137, 21, 0)
                                  : theme[Get.find<controllerphoneinfo>(
                                          tag: 'secend')
                                      .theme
                                      .value]![3],
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          shadows: [
                            BoxShadow(
                              color: index % 2 == 0
                                  ? Color.fromARGB(126, 68, 227, 115)
                                  : index % 1.5 == 0
                                      ? Color.fromARGB(125, 227, 68, 68)
                                      : Color.fromARGB(124, 227, 216, 68),
                              blurRadius: 8,
                              offset: Offset(0, 0),
                              spreadRadius: 0,
                            )
                          ],
                        ),
                      ),
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

class drawer extends StatelessWidget {
  const drawer({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          InkWell(
            onTap: () => Get.bottomSheet(Container(
              width: Get.width,
              // height: Get.height * 0.4,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Text(
                        'شما در حال حاظر ${Get.find<controllerphoneinfo>(tag: 'secend').lenghtmainpage.value}دستگاه دارید'),
                    Text(
                      'میتوانید از بین دستکاه ها یکی را انتخاب کنید',
                      style: TextStyle(
                          fontFamily: 'A', fontWeight: FontWeight.bold),
                    ),
                    Column(
                      children: List.generate(
                          Get.find<controllerphoneinfo>(tag: 'secend')
                              .lenghtmainpage
                              .value,
                          (index) => InkWell(
                                onTap: () {
                                  Get.find<controllerphoneinfo>(tag: 'secend')
                                      .changepage(index);
                                  Get.find<controlleronoff>(tag: 'secend')
                                      .open_drawer
                                      .value = false;
                                  Get.back();
                                },
                                child: Container(
                                  width: Get.width * 0.7,
                                  margin: EdgeInsets.only(bottom: 10, top: 10),
                                  height: 48,
                                  decoration: ShapeDecoration(
                                    color: theme[Get.find<controllerphoneinfo>(
                                            tag: 'secend')
                                        .theme
                                        .value]![4],
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(8)),
                                    shadows: [
                                      BoxShadow(
                                        color: theme[
                                            Get.find<controllerphoneinfo>(
                                                    tag: 'secend')
                                                .theme
                                                .value]![5],
                                        blurRadius: 8,
                                        offset: Offset(0, 0),
                                        spreadRadius: 0,
                                      )
                                    ],
                                  ),
                                  child: Column(
                                    children: [
                                      Text(
                                        Get.find<controllerphoneinfo>(
                                                tag: 'secend')
                                            .phoness[index]
                                            .Name,
                                        style: TextStyle(fontFamily: 'A'),
                                      ),
                                      Text(
                                          Get.find<controllerphoneinfo>(
                                                  tag: 'secend')
                                              .phoness[index]
                                              .phone,
                                          style: TextStyle(fontFamily: 'A')),
                                    ],
                                  ),
                                ),
                              )),
                    ),
                  ],
                ),
              ),
            )),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Obx(() {
                  return Text(
                    Get.find<controllerphoneinfo>(tag: 'secend').Name.value ==
                            ''
                        ? 'بدون دستگاه'
                        : Get.find<controllerphoneinfo>(tag: 'secend')
                            .Name
                            .value,
                    style: TextStyle(fontSize: 18, fontFamily: 'A'),
                  );
                }),
                SizedBox(
                  width: 30,
                ),
                Obx(() {
                  return Visibility(
                    visible: Get.find<controllerphoneinfo>(tag: 'secend')
                                .lenghtmainpage
                                .value >
                            1
                        ? true
                        : false,
                    replacement: SvgPicture.asset(
                      'assets/profile-circle.svg',
                      //  semanticsLabel: 'tttttt',
                      // package: 'r',
                    ),
                    child: badges.Badge(
                      child: SvgPicture.asset(
                        'assets/profile-circle.svg',
                        //  semanticsLabel: 'tttttt',
                        // package: 'r',
                      ),
                      badgeContent: Text(
                          '${Get.find<controllerphoneinfo>(tag: 'secend').lenghtmainpage.value}'),
                    ),
                  );
                }),
                SizedBox(
                  width: 5,
                )
              ],
            ),
          ),
          SizedBox(
            height: 50,
          ),
          Column(
            children: List.generate(
              pages.length,
              (index) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: InkWell(
                  onTap: () {
                    if (index != 2) {
                      Get.to(pages[index]);
                    } else {
                      Get.find<controlleronoff>(tag: 'secend').relleh.value =
                          true;
                    }
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        namepages[index],
                        style: TextStyle(fontFamily: 'A', color: Colors.white),
                      ),
                      SizedBox(
                        width: 30,
                      ),
                      SvgPicture.asset(
                        namesvg[index],
                        height: index == 1 ? 20 : null,
                      ),
                      SizedBox(
                        width: 5,
                      )
                    ],
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}

List<Widget> pages = [
  AddDevice(),
  Contacts(),
  Relleh(),
  simcard(),
  PasswordApp(),
  PasswordDevice(),
  Setting(),
];
List<String> namepages = [
  'افزودن دستگاه',
  'مخاطبین(مدیران)',
  'رله',
  'سیمکارت',
  'پسورد نرم افزار',
  'پسورد دستگاه',
  'تنظیمات',
];
List<String> namesvg = [
  'assets/add.svg',
  'assets/profile-circle.svg',
  'assets/electricity.svg',
  'assets/simcard.svg',
  'assets/pass-dev.svg',
  'assets/pass-dev.svg',
  'assets/setting-2.svg',
];
List<String> name_dev = [
  'مغازه 1',
  'مغازه 2',
  'کارگاه1',
  'کارگاه2',
  'منزل 1',
  'منزل 2',
  'پارکینگ 1',
  'ویلا',
  'باغ',
  'مزرعه',
];
