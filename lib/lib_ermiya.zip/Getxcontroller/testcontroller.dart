import 'package:flutter/material.dart';
import 'package:get/get.dart';

class testcontroller extends GetxController {
  RxString onofff = 'on'.obs;
}
