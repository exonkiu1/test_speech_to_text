import 'package:flutter_sms/flutter_sms.dart';
import 'package:get/get.dart';
import 'package:test_speech_to_text/Getxcontroller/controllerphoneinfo.dart';

sendsms(String message) async {
  await sendSMS(message: message, recipients: [
    '+98${Get.find<controllerphoneinfo>(tag: 'secend').phone.value}'
  ]).catchError((onError) {
    print(onError);
  });
}
